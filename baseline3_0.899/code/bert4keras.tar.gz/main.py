import json
import os

import numpy as np
import pandas as pd
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras.utils import multi_gpu_model

from bert4keras.bert import load_pretrained_model, set_gelu
from bert4keras.utils import SimpleTokenizer, load_vocab

data = open('../../data/train_data.txt','r').read().split('\n')[:-1]

set_gelu('tanh')

config_path = 'model_1/albert_large_zh/albert_config_large.json'
checkpoint_path = 'model_1/albert_large_zh/albert_model.ckpt'
dict_path = 'model_1/albert_large_zh/vocab.txt'

chars = {}
data = open('bert_.txt','r').read().split('\n')[:-1]
data_test = open('test.txt','r').read().split('\n')[:-1]
for dd in data + data_test:
    pass
    for c in dd.split('\t')[0]+dd.split('\t')[1]:
        if c is not None:
            if c in chars.keys():
                chars[c] = chars[c] + 1
            else:
                chars[c] = 1

_token_dict = load_vocab(dict_path)  
token_dict, keep_words = {}, []  

for c in ['[PAD]', '[UNK]', '[CLS]', '[SEP]', '[unused1]']:
    token_dict[c] = len(token_dict)
    keep_words.append(_token_dict[c])

for c in chars:
    if c in _token_dict:
        token_dict[c] = len(token_dict)
        keep_words.append(_token_dict[c])


tokenizer_2 = SimpleTokenizer(token_dict) 



train_X_1 = []
train_X_2 = []
train_Y_ = []

test_X_1 = []
test_X_2 = []

X1 = []
X2 = []
Y = []
for dd in data:
    pass
    train_X_1.append( dd.split('\t')[0] )
    train_X_2.append( dd.split('\t')[1] )
    
    train_Y_.append( int(dd.split('\t')[2]) )
    
    x1,x2 = tokenizer_2.encode(dd.split('\t')[0],dd.split('\t')[1])
    
    while len(x1)<138:
        x1.append(0)

    while len(x2)<138:
        x2.append(0)
    
    
    X1.append(x1[:138])
    X2.append(x2[:138])
    
    Y.append( [int(dd.split('\t')[2])] )
    
#    if len(X1)>500:
#        break
    
#     break
#     for c in +dd.split('\t')[1]:
# test_X_1 = []
# test_X_2 = []
# for dd in data_test:
#     pass
#     test_X_1.append( dd.split('\t')[0] )
#     test_X_2.append( dd.split('\t')[1] )
    
X1 = np.array(X1)
X2 = np.array(X2)

from keras import utils
YYYY_ = utils.to_categorical(Y)
from sklearn.utils import shuffle
X1_array ,X2_array ,Y_array = shuffle(X1 ,X2 ,np.array(YYYY_))
from keras.layers import *
from keras.models import Model
from keras.optimizers import Adam
output = Lambda(lambda x: x[:, 0])(model.output)
output = Dense(2, activation='softmax')(output)

model_yan = Model(model.input, output)

model_yan.compile(
    loss='categorical_crossentropy',
    optimizer=Adam(),  
    metrics=['accuracy']
)

model_yan.fit([X1_array,
               X2_array],Y_array,
              batch_size=20,
              epochs=500,
              validation_split=0.1)




















